import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { chromium } from 'playwright';
import AxeBuilder from '@axe-core/playwright';

const output = '/workspace/scratch/cd713ff3be95/relay-evidence';
const browser = await chromium.launch();
const results = { browser: browser.version(), checks: [], measurements: {} };
const context = await browser.newContext({ viewport: { width: 1366, height: 768 } });
const page = await context.newPage();
const button = (name) => page.getByRole('button', { name, exact: true });
const check = (name) => results.checks.push(name);
async function overflow(name) {
  const size = await page.evaluate(() => ({ width: innerWidth, scroll: document.documentElement.scrollWidth }));
  assert.ok(size.scroll <= size.width, `${name}: ${size.scroll} > ${size.width}`);
  check(`${name}: no horizontal overflow`);
}
async function axe(name) {
  const report = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa']).analyze();
  assert.deepEqual(report.violations.map(v => v.id), [], name);
  check(`${name}: zero axe violations`);
}
try {
  await page.goto('http://127.0.0.1:4184/');
  await button('Try A1').click();
  await button('Prepare manually').click();
  await page.evaluate(async () => { await document.fonts.ready; scrollTo(0, 0); });
  const pending = await button('Approve this text').boundingBox();
  results.measurements.pendingButtonBottom = pending.y + pending.height;
  assert.ok(pending.y + pending.height <= 768, 'Pending approval CTA must fit desktop viewport');
  check('1366x768: pending approval CTA visible');
  await page.locator('#sharing-copy').focus();
  await page.keyboard.press('Tab');
  assert.equal(await button('Line 6').evaluate(e => e === document.activeElement), true);
  await page.keyboard.press('Enter');
  assert.equal(await page.locator('#private-original').evaluate(e => e === document.activeElement && e.readOnly && e.selectionEnd > e.selectionStart), true);
  check('Keyboard: line reference focuses and selects readonly original');
  await button('Approve this text').focus();
  await page.keyboard.press('Enter');
  assert.equal(await page.locator('.approval-state').textContent(), 'Copy approved');
  await page.evaluate(() => scrollTo(0, 0));
  const approved = await button('Open handoff').boundingBox();
  results.measurements.approvedButtonBottom = approved.y + approved.height;
  assert.ok(approved.y + approved.height <= 768, 'Open handoff CTA must fit desktop viewport');
  check('1366x768: approved handoff CTA visible');
  await page.locator('#sharing-copy').fill((await page.locator('#sharing-copy').inputValue()) + '\nReview updated.');
  assert.equal(await page.locator('.approval-state').textContent(), 'Approval revoked');
  assert.equal(await button('Open handoff').count(), 0);
  check('Editing revokes approval and removes Open handoff');
  const revokedColors = await page.locator('[data-approval="revoked"]').evaluateAll(nodes => nodes.map(e => getComputedStyle(e).color));
  assert.ok(revokedColors.length >= 2);
  assert.deepEqual([...new Set(revokedColors)], ['rgb(142, 48, 39)']);
  results.measurements.revokedTextColors = revokedColors;
  check('Revoked state uses the same error color in inspector and approval strip');
  await page.screenshot({ path: `${output}/after/1366-revoked.png`, fullPage: true });

  for (const width of [320, 624, 625, 928, 929, 1120, 1121]) {
    await page.setViewportSize({ width, height: 844 });
    await overflow(`Review ${width}px`);
  }
  const mobileGap = await page.locator('.comparison .incident-document').nth(1).evaluate(e => getComputedStyle(e).marginTop);
  await page.setViewportSize({ width: 320, height: 844 });
  results.measurements.mobileDocumentGap = await page.locator('.comparison .incident-document').nth(1).evaluate(e => getComputedStyle(e).marginTop);
  assert.equal(results.measurements.mobileDocumentGap, '12px');
  check('320px: 12px separation between documents');

  await page.getByRole('button', { name: /Capture/ }).click();
  await page.locator('#original-notes').fill('10:02 Search timed out.\n10:05 Investigation continues.');
  await button('Prepare manually').click();
  assert.match(await page.locator('.annotations > p').innerText(), /No exclusions listed/);
  await overflow('Empty exclusions 320px');
  await axe('Empty exclusions 320px');
  await page.screenshot({ path: `${output}/after/320-empty-exclusions.png`, fullPage: true });

  await page.locator('#sharing-copy').fill('Synthetic note. '.repeat(450));
  assert.equal(await page.locator('#sharing-copy').getAttribute('aria-invalid'), 'true');
  assert.equal(await button('Approve this text').isEnabled(), false);
  assert.equal(await page.locator('#sharing-copy-error').isVisible(), true);
  await overflow('Invalid sharing copy 320px');
  await axe('Invalid sharing copy 320px');
  await page.emulateMedia({ forcedColors: 'active' });
  await page.locator('#private-original').focus();
  await page.keyboard.press('Tab');
  assert.equal(await page.locator('#sharing-copy').evaluate(e => e === document.activeElement && e.matches(':focus-visible')), true);
  const focus = await page.locator('#sharing-copy').evaluate(e => { const s=getComputedStyle(e); return { width:s.outlineWidth, style:s.outlineStyle, color:s.outlineColor, offset:s.outlineOffset }; });
  results.measurements.forcedColorsInvalidFocus = focus;
  assert.equal(focus.width, '2px');
  assert.equal(focus.style, 'solid');
  check('Forced colors: invalid sharing copy retains visible 2px keyboard focus');
  await page.screenshot({ path: `${output}/after/320-forced-colors-invalid.png`, fullPage: true });
  results.status = 'passed';
} catch (error) {
  results.status = 'failed';
  results.failure = String(error);
  throw error;
} finally {
  await writeFile(`${output}/review-checks.json`, JSON.stringify(results, null, 2) + '\n');
  console.log(JSON.stringify(results, null, 2));
  await browser.close();
}
